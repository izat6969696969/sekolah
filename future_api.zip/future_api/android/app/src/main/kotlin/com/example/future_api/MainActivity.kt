package com.example.future_api

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
